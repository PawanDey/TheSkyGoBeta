package com.global.travel.telecom.app;

import android.app.Application;

public class MyApplication extends Application {
}
