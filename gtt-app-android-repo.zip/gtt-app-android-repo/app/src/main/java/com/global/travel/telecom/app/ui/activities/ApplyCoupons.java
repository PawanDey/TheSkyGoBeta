package com.global.travel.telecom.app.ui.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.global.travel.telecom.app.R;

public class ApplyCoupons extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_coupons);
    }

}
