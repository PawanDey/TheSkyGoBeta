package com.global.travel.telecom.app.ui.activities;

public class translatPassdata {
    String mDealerName;
    String mAlertTime;
    String mMessage;

    translatPassdata(String mDealerName, String mMessage, String mAlertTime) {
        this.mDealerName = mDealerName;
        this.mMessage = mMessage;
        this.mAlertTime = mAlertTime;
    }
}