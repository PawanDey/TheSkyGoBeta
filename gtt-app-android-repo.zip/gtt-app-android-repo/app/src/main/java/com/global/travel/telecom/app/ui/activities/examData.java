package com.global.travel.telecom.app.ui.activities;
   public class examData {
       String name;
       String date;
       String message;

       examData(String name, String date, String message) {
           this.name = name;
           this.date = date;
           this.message = message;
       }
   }